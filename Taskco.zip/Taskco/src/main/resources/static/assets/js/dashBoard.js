// 대쉬보드 기능
//로직 
// 1. 각 열, 각 위치에 있는 카드를 불러옴. 
// 2. 각 카드별로 status 값을 기준으로 분류해서 개수 산출 

const observer = new MutationObserver(() => {
    let allTask = document.querySelectorAll(".task"); // 모든 태스크를 담는 변수
    console.log("allTask", allTask);

    let todoTask = 0;
    let doingTask = 0;
    let doneTask = 0;

    allTask.forEach(task => {
        if (task.dataset.status === "todo") {
            todoTask += 1;
        } else if (task.dataset.status === "doing") {
            doingTask += 1;
        } else if (task.dataset.status === "done") {
            doneTask += 1;
        }
    });

    console.log("TODO:", todoTask, "DOING:", doingTask, "DONE:", doneTask);
});

// 감시 시작
observer.observe(document.body, { childList: true, subtree: true });