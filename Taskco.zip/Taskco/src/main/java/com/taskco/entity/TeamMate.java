package com.taskco.entity;

import lombok.Data;

@Data
public class TeamMate {
	private String join_idx;
	private String profile_img;
	private String name;
	private String role;
	private String email;

}
