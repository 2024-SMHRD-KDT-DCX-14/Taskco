package com.taskco.entity;

import lombok.Data;

@Data
public class Croom {
   private int croom_idx;
   private String croom_dt;
   private String croom_status;
   private String p_idx;
}