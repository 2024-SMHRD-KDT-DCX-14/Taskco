package com.taskco.entity;


import lombok.Data;

@Data
public class Project {

	private String p_idx;

	private String p_title;

	private String p_desc;

	private String email;

	private String st_dt;

	private String ed_dt;

	private String p_status;

}
