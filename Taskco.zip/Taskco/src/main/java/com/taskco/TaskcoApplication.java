package com.taskco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskcoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskcoApplication.class, args);
	}

}
